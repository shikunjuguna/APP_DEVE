-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2021 at 03:37 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admission_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `admission_details`
--

CREATE TABLE `admission_details` (
  `form_id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `middle_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `date_of_birth` date NOT NULL,
  `citizenship` varchar(30) NOT NULL,
  `country_of_birth` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `county_of_birth` varchar(30) NOT NULL,
  `id/passport_number` int(30) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `years_of_formal_education` int(50) NOT NULL,
  `highest_level_of_education` varchar(50) NOT NULL,
  `others` text NOT NULL,
  `photo` blob NOT NULL,
  `languages` text NOT NULL,
  `disability` varchar(50) NOT NULL,
  `nature` text NOT NULL,
  `religion` varchar(50) NOT NULL,
  `other_religions` text NOT NULL,
  `postal_address` varchar(50) NOT NULL,
  `postal_code` int(50) NOT NULL,
  `town` varchar(50) NOT NULL,
  `country` varchar(30) NOT NULL,
  `telephone` int(30) NOT NULL,
  `mobile_no` int(30) NOT NULL,
  `email_address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admission_details`
--
ALTER TABLE `admission_details`
  ADD PRIMARY KEY (`form_id`),
  ADD UNIQUE KEY `form_id` (`form_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admission_details`
--
ALTER TABLE `admission_details`
  MODIFY `form_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
