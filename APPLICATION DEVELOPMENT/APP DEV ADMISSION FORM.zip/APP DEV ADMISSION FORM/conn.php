<?php
include './dbconfig.php';

// REGISTER

// Check if register button is clicked

if (isset($_POST['next'])) {

    // Get user data
    $first_name = $_POST['first-name'];
    $last_name = $_POST['last-name'];
    $email = $_POST['email'];
 $FIRSTNAME=$_POST['FIRSTNAME'];
 $MIDDLENAME=$_POST['MIDDLENAME'];
 $LASTNAME=$_POST['LASTNAME'];
 $DATE_OF_BIRTH=$_POST['DATE_OF_BIRTH'];
 $CITIZENSHIP=$_POST['CITIZENSHIP'];
 $countryCode=$_POST['countryCode'];
 $EMAIL=$_POST['EMAIL'];
 $County=$_POST['County'];
 $PASSPORT=$_POST['PASSPORT'];
 $Gender=$_POST['Gender'];
 $FORMAL_EDUCATION=$_POST['FORMAL_EDUCATION'];
 $Level=$_POST['Level'];
 $Others=$_POST['Others'];
 $photo_btn=$_POST['photo_btn'];
 $Languanges=$_POST['Languanges'];
 $Disability=$_POST['Disability'];
 $Disability=$_POST['Disability'];
 $Religion=$_POST['Religion'];
 $Others=$_POST['Others'];
 $Postal_address=$_POST['Postal_address'];
 $Postal_code=$_POST['Postal_code'];
 $Town=$_POST['Town'];
 $Country=$_POST['Country'];
 $Telephone=$_POST['Telephone'];
 $Mobile_number=$_POST['Mobile_number'];
 $Email_addresse=$_POST['Email_addresse'];

    // check if values are empty
    if ($first_name == '' || $last_name == '' || $email == '' ||$password == '') {
        echo "<script>alert('Please fill in all the inputs')</script>";
    } 
    else {

        //  Check if the user exists in the database
        $check = "SELECT * FROM admission_details WHERE email = '$email' ";
        $check_user = mysqli_query($con, $check);

        // if user exists, echo user already exists
        $numrows = mysqli_num_rows($check_user);

        if($numrows > 0){
            echo "<script>alert('User aleady exists')</script>";
        }

        // if user doesn't exist, create new user, echo success
        if($numrows == 0){
            $query = "INSERT INTO admission_details(
                       first_name,middle_name,last_name,date_of_birth,citizenship,country_of_birth,email,county_of_birth,id/passport_number,Gender,years_of_formal_education,highest_level_of_education,others,photo,languages,disability,nature,religion,other_religions,postal_address,postal_code,town,country,telephone,mobile_no,email_address)
                       VALUES('$FIRSTNAME','$MIDDLENAME','$LASTNAME','$DATE_OF_BIRTH','$CITIZENSHIP','$countryCode','$EMAIL','$County','$PASSPORT','$Gender','$FORMAL_EDUCATION','$Level','$Others','$photo_btn','$Languanges','$Disability','$Disability','$Religion','$Others','$Postal_address','$Postal_code','$Town','$Country',$Telephone','$Mobile_number','$Email_addresse')";

            $run = mysqli_query($con, $query);

            if($run){
                echo "<script>alert('Registration successfull')</script>";
            }else{
                echo "<script>alert('Registration Failed')</script>";
            }
        }
    }
}