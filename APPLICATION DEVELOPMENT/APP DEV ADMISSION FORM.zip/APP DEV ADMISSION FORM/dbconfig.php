<!-- Connecting to the database -->
<?php
$servername = 'localhost';
$username = 'root'; //edit if you have set a username for MySQL
$password = ''; // edit if you have set a password
$dbname = 'admission_form';
// Create connection syntax
$conn = new mysqli($servername, $username, $password, $dbname) or die("Unable to connect.");
//Check connection
//if ($conn->connect_error) {
 //    die('Connection failed: '. $conn->connect_error);
//}
echo "record saved successfully";
//echo "'Dear ' FIRSTNAME , LASTNAME ',Your application has been successfully submitted.Please await the outcome in two weeks time.Yours Registrar. ";
?>

