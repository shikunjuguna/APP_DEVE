
<div id="index">
<link href="//fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" />
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <link rel="stylesheet" type="text/css" href="form.css">
<div class="header">
<h1> APPLICATION FOR ADMISSION</h1></div>
<h3>APPLICATION PROCEDURE</h3>
<p>1. Attach photocopies of all academic and proffessional certificates.If they are not in English send translated and certified copies.Non-English Speakers must provide proof of competence in English. </p>
<p>2. Attach a copy of your recent colored passport size photographs.</p>
<p>3. Please note that you are required to ay a non-refundable application fee for your application to be processed</p>
	<h3>APPLICATION FEES</h3><ol>
	<l1>Postgraduate Application fee- 3000 kshs</l1><br>
	<l2>Undergraduate Application fee- 1500 kshs</l2><br>
	<l3>Diploma and Certificate Application fee- 1000 kshs</l3></tr></ol><br>
	
	<h3>PERSONAL INFORMATION</h3>

<form method="post" action="conn.php" enctype="multipart/form-data">
	<div class="input-group">
		<label>Firstname :</label><br>
		<input type="text" name="FIRSTNAME" required placeholder="Enter Firstname" >
	</div>
	<div class="input-group">
		<label>Middlename :</label><br>
		<input type="text" name="MIDDLENAME" required placeholder="Enter Middlename" >
	</div>
	<div class="input-group">
		<label>Lastname :</label><br>
		<input type="text" name="LASTNAME" required placeholder="Enter Lastname" >
	</div>
	<div class="input-group">
		<label>Date of birth :</label><br>
		<input type="Date" name="DATE_OF_BIRTH">
	</div>
	<div class="input-group">
		<label>Citizenship :</label><br>
        <input type="text" name="CITIZENSHIP" required placeholder="Enter Citizenship">
	</div>
	<div class="input-group">
		<label>Country of birth</label><br>
	<select name="countryCode" id="">
		<option value="">Choose country</option>
	    <option  value="44">UK </option>
	    <option  value="1">USA </option>
		<option value="213">Algeria</option>
		<option value="376">Andorra </option>
		<option value="244">Angola</option>
		<option value="1264">Anguilla</option>
		<option value="1268">Antigua</option>
		<option value="54">Argentina</option>
		<option value="374">Armenia </option>
		<option value="297">Aruba </option>
		<option value="61">Australia</option>
		<option value="43">Austria </option>
		<option value="994">Azerbaijan</option>
		<option value="1242">Bahamas </option>
		<option value="973">Bahrain </option>
		<option value="880">Bangladesh </option>
		<option value="1246">Barbados </option>
		<option value="375">Belarus </option>
		<option value="32">Belgium</option>
		<option value="501">Belize </option>
		<option value="229">Benin </option>
		<option value="1441">Bermuda </option>
		<option value="975">Bhutan </option>
		<option value="591">Bolivia </option>
		<option value="387">Bosnia Herzegovina </option>
		<option value="267">Botswana </option>
		<option value="55">Brazil </option>
		<option value="673">Brunei </option>
		<option value="359">Bulgaria </option>
		<option value="226">Burkina Faso </option>
		<option value="257">Burundi </option>
		<option value="855">Cambodia </option>
		<option value="237">Cameroon </option>
		<option value="1">Canada </option>
		<option value="238">Cape Verde Islands </option>
		<option value="1345">Cayman Islands </option>
		<option value="236">Central African Republic </option>
		<option value="56">Chile</option>
		<option value="86">China</option>
		<option value="57">Colombia</option>
		<option value="269">Comoros</option>
		<option value="242">Congo </option>
		<option value="682">Cook Island</option>
		<option value="506">Costa Rica</option>
		<option value="385">Croatia</option>
		<option value="53">Cuba /option>
		<option value="90392">Cyprus North</option>
		<option value="357">Cyprus South </option>
		<option value="42">Czech Republic </option>
		<option value="45">Denmark </option>
		<option value="253">Djibouti</option>
		<option value="1809">Dominica </option>
		<option value="1809">Dominican Republic </option>
		<option value="593">Ecuador </option>
		<option value="20">Egypt</option>
		<option value="503">El Salvador </option>
		<option value="240">Equatorial Guinea </option>
		<option value="291">Eritrea </option>
		<option value="372">Estonia </option>
		<option value="251">Ethiopia </option>
		<option value="500">Falkland Islands</option>
		<option value="298">Faroe Islands </option>
		<option value="679">Fiji </option>
		<option value="358">Finland </option>
		<option value="33">France</option>
		<option value="594">French Guiana </option>
		<option value="689">French Polynesia </option>
		<option value="241">Gabon </option>
		<option value="220">Gambia </option>
		<option value="7880">Georgia </option>
		<option value="49">Germany</option>
		<option value="233">Ghana</option>
		<option value="350">Gibraltar </option>
		<option value="30">Greece </option>
		<option value="299">Greenland </option>
		<option value="1473">Grenada </option>
		<option value="590">Guadeloupe </option>
		<option value="671">Guam</option>
		<option value="502">Guatemala</option>
		<option value="224">Guinea</option>
		<option value="245">Guinea - Bissau</option>
		<option value="592">Guyana </option>
		<option value="509">Haiti </option>
		<option value="504">Honduras </option>
		<option value="852">Hong Kong </option>
		<option value="36">Hungary </option>
		<option value="354">Iceland </option>
		<option value="91">India </option>
		<option value="62">Indonesia </option>
		<option value="98">Iran</option>
		<option value="964">Iraq </option>
		<option value="353">Ireland </option>
		<option value="972">Israel </option>
		<option value="39">Italy </option>
		<option value="1876">Jamaica </option>
		<option value="81">Japan </option>
		<option value="962">Jordan </option>
		<option value="7">Kazakhstan </option>
		<option value="254">Kenya</option>
		<option value="686">Kiribati </option>
		<option value="850">Korea North </option>
		<option value="82">Korea South </option>
		<option value="965">Kuwait </option>
		<option value="996">Kyrgyzstan </option>
		<option value="856">Laos </option>
		<option value="371">Latvia </option>
		<option value="961">Lebanon </option>
		<option value="266">Lesotho </option>
		<option value="231">Liberia </option>
		<option value="218">Libya </option>
		<option value="417">Liechtenstein </option>
		<option value="370">Lithuania </option>
		<option value="352">Luxembourg</option>
		<option value="853">Macao </option>
		<option value="389">Macedonia </option>
		<option value="261">Madagascar </option>
		<option value="265">Malawi </option>
		<option value="60">Malaysia </option>
		<option value="960">Maldives </option>
		<option value="223">Mali </option>
		<option value="356">Malta </option>
		<option value="692">Marshall Islands</option>
		<option value="596">Martinique </option>
		<option value="222">Mauritania </option>
		<option value="269">Mayotte</option>
		<option value="52">Mexico </option>
		<option value="691">Micronesia</option>
		<option value="373">Moldova </option>
		<option value="377">Monaco </option>
		<option value="976">Mongolia </option>
		<option value="1664">Montserrat </option>
		<option value="212">Morocco </option>
		<option value="258">Mozambique </option>
		<option value="95">Myanmar </option>
		<option value="264">Namibia </option>
		<option value="674">Nauru </option>
		<option value="977">Nepal </option>
		<option value="31">Netherlands </option>
		<option value="687">New Caledonia </option>
		<option value="64">New Zealand </option>
		<option value="505">Nicaragua </option>
		<option value="227">Niger </option>
		<option value="234">Nigeria </option>
		<option value="683">Niue </option>
		<option value="672">Norfolk Islands </option>
		<option value="670">Northern Marianas </option>
		<option value="47">Norway </option>
		<option value="968">Oman </option>
		<option value="680">Palau </option>
		<option value="507">Panama </option>
		<option value="675">Papua New Guinea </option>
		<option value="595">Paraguay </option>
		<option value="51">Peru </option>
		<option value="63">Philippines </option>
		<option value="48">Poland </option>
		<option value="351">Portugal </option>
		<option value="1787">Puerto Rico </option>
		<option value="974">Qatar </option>
		<option value="262">Reunion </option>
		<option value="40">Romania</option>
		<option value="7">Russia </option>
		<option value="250">Rwanda </option>
		<option value="378">San Marino </option>
		<option value="239">Sao Tome &amp; Principe </option>
		<option value="966">Saudi Arabia </option>
		<option value="221">Senegal </option>
		<option value="381">Serbia </option>
		<option value="248">Seychelles </option>
		<option value="232">Sierra Leone </option>
		<option value="65">Singapore </option>
		<option value="421">Slovak Republic </option>
		<option value="386">Slovenia </option>
		<option value="677">Solomon Islands </option>
		<option value="252">Somalia </option>
		<option value="27">South Africa </option>
		<option value="34">Spain </option>
		<option value="94">Sri Lanka </option>
		<option value="290">St. Helena </option>
		<option value="1869">St. Kitts </option>
		<option value="1758">St. Lucia </option>
		<option value="249">Sudan </option>
		<option value="597">Suriname </option>
		<option value="268">Swaziland </option>
		<option value="46">Sweden </option>
		<option value="41">Switzerland </option>
		<option value="963">Syria </option>
		<option value="886">Taiwan </option>
		<option value="7">Tajikstah</option>
		<option value="66">Thailand</option>
		<option value="228">Togo </option>
		<option value="676">Tonga </option>
		<option value="1868">Trinidad &amp; Tobago </option>
		<option value="216">Tunisia </option>
		<option value="90">Turkey </option>
		<option value="7">Turkmenistan </option>
		<option value="993">Turkmenistan </option>
		<option value="1649">Turks &amp; Caicos Islands </option>
		<option value="688">Tuvalu </option>
		<option value="256">Uganda </option>
		<option value="380">Ukraine </option>
		<option value="971">United Arab Emirates </option>
		<option value="598">Uruguay </option>
		<option value="7">Uzbekistan </option>
		<option value="678">Vanuatu </option>
		<option value="379">Vatican City </option>
		<option value="58">Venezuela </option>
		<option value="84">Vietnam </option>
		<option value="84">Virgin Islands - British </option>
		<option value="84">Virgin Islands - US </option>
		<option value="681">Wallis &amp; Futuna </option>
		<option value="969">Yemen (North)</option>
		<option value="967">Yemen (South)</option>
		<option value="260">Zambia </option>
		<option value="263">Zimbabwe </option>
	</optgroup>
</select>
	</div>
	<div class="input-group">
		<label>Email :</label><br>
        <input type="email" name="EMAIL" required placeholder="qwerty@gmail.com">
	</div>
	<div class="input-group">
	<label>County of birth :</label><br>
     <select name="County" required>
     	<option value="" selected>Choose county</option>
     	<option value="Kiambu">Kiambu</option>
        <option value="Nairobi">Nairobi</option>
        <option value="Mombasa">Mombasa</option>
        <option value="	Kwale">	Kwale</option>
        <option value="	Kilifi">Kilifi</option>
        <option value="Tana River">Tana River</option>
        <option value="	Lamu">	Lamu</option>
        <option value="Taita–Taveta">Taita–Taveta</option>
        <option value="Garissa">Garissa</option>
        <option value="Wajir">Wajir</option>
        <option value="Mandera">Mandera</option>
        <option value="	Marsabit">	Marsabit</option>
        <option value="	Isiolo">Isiolo</option>
        <option value="	Meru">	Meru</option>
        <option value="Tharaka-Nithi">Tharaka-Nithi</option>
        <option value="	Embu">	Embu</option>
        <option value="	Kitui">	Kitui</option>
        <option value="Machakos">Machakos</option>
        <option value="Makueni">Makueni</option>
        <option value="	Nyandarua">	Nyandarua</option>
        <option value="Nyeri">Nyeri</option>
        <option value="	Kirinyaga">	Kirinyaga</option>
        <option value="	Murang'a">	Murang'a</option>
        <option value="Turkana">Turkana</option>
        <option value="	West Pokot">West Pokot</option>
        <option value="Samburu">Samburu</option>
        <option value="Trans-Nzoia">Trans-Nzoia</option>
        <option value="Uasin Gishu">Uasin Gishu</option>
        <option value="	Elgeyo-Marakwet">Elgeyo-Marakwet</option>
        <option value="	Nandi">	Nandi</option>
        <option value="Baringo">Baringo</option>
        <option value="Laikipia">Laikipia</option>
        <option value="Nakuru">Nakuru</option>
        <option value="	Narok">	Narok</option>
        <option value="Kajiado">Kajiado</option>
        <option value="	Kericho">Kericho</option>
        <option value="Bomet">Bomet</option>
        <option value="Kakamega">Kakamega</option>
        <option value="Vihiga">Vihiga</option>
        <option value="	Bungoma">Bungoma</option>
        <option value="	Busia">	Busia</option>
        <option value="Siaya">Siaya</option>
        <option value="	Kisumu">Kisumu</option>
        <option value="	Homa Bay">	Homa Bay</option>
        <option value="Migori">Migori</option>
        <option value="Kisii">Kisii</option>
        <option value="Nyamira">Nyamira</option>
       
     </select>
 
</div>
<div class="input-group">
	<label>ID/Passport number</label><br>
	<input type="number" name="PASSPORT" required placeholder="e.g 1234567890">
</div>
<div class="input-group">
 <label>Gender</label><br>
    <input type="radio"name="Gender"value="male">male
    <input type="radio"name="Gender"value="female">female<br></div>
<div class="input-group">
	<label>Years of formal education</label><br>
	<input type="number" name="FORMAL_EDUCATION" required placeholder=" e.g 10">
</div>
<div class="input-group">
 <label>Highest level of education</label><br>
    <input type="radio"name="Level"value="primary">Primary
    <input type="radio"name="Level"value="secondary">Secondary
    <input type="radio"name="Level"value="undergraduate">Undergraduate
    <input type="radio"name="Level"value="postgraduate">Postgraduate
    <input type="radio"name="Level"value="others">Others</div>
<div class="input-group">
	<label>If others please specify</label><br>
	<input type="text" name="Others">
</div>
<div class="input-group">
	<label>Upload passport size photo </label>
		<div class="btn1"><button type="img" class="button" name="photo_btn">choose photo</button></div>
		</div>
<div class="input-group">
	<label>Other languages spoken or written</label><br>
	<input type="text" name="Languages">
</div>
<div class="input-group">
<label>Do you have any disability? </label>
    <input type="radio"name="Disability"value="yes">Yes
    <input type="radio"name="Disability"value="no">No<br></div>
    <div class="input-group">
	<label>If yes please explain nature of disability </label>
	<input type="text" name="Disability">
</div>
<h3>RELIGIOUS AFFLIATION</h3>
<div class="input-group">
<label>Religious Affliations </label><br>
    <input type="radio"name="Religion"value="Protestant">Protestant
    <input type="radio"name="Religion"value="Roman Catholic">Roman Catholic
    <input type="radio"name="Religion"value="Hindu">Hindu
    <input type="radio"name="Religion"value="African Traditional Religion">African Traditional Religion
    <input type="radio"name="Religion"value="Muslim">Muslim
    <input type="radio"name="Religion"value="Ordanied minister">Ordanied minister(For Divinity Applicants only)
    <input type="radio"name="Religion"value="Others">Others</div>
<div class="input-group">
	<label>If others please specify </label>
	<input type="text" name="Others">
</div>
<h3>CURRENT ADDRESS</h3>
<div class="input-group">
	<label>POSTAL ADDRESS</label><br>
	<input type="text" name="Postal_address">
</div><div class="input-group">
	<label>POSTAL CODE </label><br>
	<input type="number" name="Postal_code">
</div><div class="input-group">
	<label>TOWN </label><br>
	<input type="text" name="Town">
</div><div class="input-group">
	<label>COUNTRY</label><br>
	<input type="text" name="Country">
</div><div class="input-group">
	<label>TELEPHONE(home) </label><br>
	<input type="number" name="Telephone">
</div><div class="input-group">
	<label>MOBILE NUMBER</label><br>
		<input type="number" name="Mobile_number">
</div><div class="input-group">
	<label>EMAIL ADDRESS </label><br>
	<input type="text" name="Email_address">
</div><br>
<button type="submit" class="btn" name="next_btn">next</button>

</form>



